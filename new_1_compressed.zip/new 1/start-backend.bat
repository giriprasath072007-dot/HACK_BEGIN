@echo off
title SourceVerify AI - Backend Server
echo ========================================================
echo   Starting SourceVerify AI Backend (Express + MongoDB)
echo ========================================================
set "PATH=%LOCALAPPDATA%\nodejs;%PATH%"
cd backend
node server.js
pause
