@echo off
title SourceVerify AI - MERN Stack Launcher
echo ========================================================
echo   SourceVerify AI - Full MERN Stack Launcher
echo ========================================================
echo.
set "PATH=%LOCALAPPDATA%\nodejs;%PATH%"

echo Starting Backend Server (Node.js + Express on Port 5000)...
start "SourceVerify Backend" cmd /k "cd backend && set PATH=%LOCALAPPDATA%\nodejs;%PATH% && node server.js"

echo Waiting for backend to initialize...
timeout /t 2 /nobreak >nul

echo Starting Frontend Server (React + Vite on Port 5173)...
start "SourceVerify Frontend" cmd /k "cd frontend && set PATH=%LOCALAPPDATA%\nodejs;%PATH% && npm run dev"

echo Waiting for frontend to start...
timeout /t 3 /nobreak >nul

echo Opening SourceVerify AI in your browser...
start http://localhost:5173

echo.
echo ========================================================
echo   MERN Application is running!
echo   Frontend: http://localhost:5173
echo   Backend:  http://localhost:5000/api/health
echo ========================================================
pause
