@echo off
title SourceVerify AI - React Frontend
echo ========================================================
echo   Starting SourceVerify AI Frontend (React + Vite)
echo ========================================================
set "PATH=%LOCALAPPDATA%\nodejs;%PATH%"
cd frontend
npm run dev
pause
