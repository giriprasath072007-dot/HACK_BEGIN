const mongoose = require("mongoose");

let isMongoConnected = false;

const connectDB = async () => {
  const uri = process.env.MONGO_URI || "mongodb://127.0.0.1:27017/sourceverify";
  try {
    mongoose.set("strictQuery", true);
    await mongoose.connect(uri, {
      serverSelectionTimeoutMS: 2500
    });
    isMongoConnected = true;
    console.log(`[MongoDB] Connected successfully to: ${uri}`);
  } catch (err) {
    isMongoConnected = false;
    console.warn(`[MongoDB Notice] Could not connect to MongoDB at ${uri} (${err.message}).`);
    console.log(`[MongoDB Fallback] Operating in Hybrid Mode (local memory store). Once MongoDB is started, it will seamlessly persist.`);
  }
};

const getMongoStatus = () => ({
  connected: isMongoConnected,
  mode: isMongoConnected ? "MongoDB Active" : "Hybrid Memory Store",
  uri: process.env.MONGO_URI || "mongodb://127.0.0.1:27017/sourceverify"
});

module.exports = { connectDB, getMongoStatus };

