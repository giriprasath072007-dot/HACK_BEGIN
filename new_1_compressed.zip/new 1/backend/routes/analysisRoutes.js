const express = require("express");
const { runAnalysis, getConflicts } = require("../controllers/analysisController");

const router = express.Router();

router.post("/run", runAnalysis);
router.get("/conflicts", getConflicts);

module.exports = router;
