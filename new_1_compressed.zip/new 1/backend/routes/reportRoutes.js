const express = require("express");
const { getExecutiveReport } = require("../controllers/reportController");

const router = express.Router();

router.get("/", getExecutiveReport);

module.exports = router;
