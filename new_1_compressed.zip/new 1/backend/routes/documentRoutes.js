const express = require("express");
const multer = require("multer");
const path = require("path");
const fs = require("fs");
const {
  getDocuments,
  getDocumentById,
  uploadDocuments,
  deleteDocument,
  loadSampleDossier,
  clearWorkspace
} = require("../controllers/documentController");

const router = express.Router();

const uploadsDir = path.join(__dirname, "../uploads");
if (!fs.existsSync(uploadsDir)) {
  fs.mkdirSync(uploadsDir, { recursive: true });
}

const storage = multer.diskStorage({
  destination: (req, file, cb) => cb(null, uploadsDir),
  filename: (req, file, cb) => {
    const safe = file.originalname.replace(/[^a-zA-Z0-9._-]/g, "_");
    cb(null, `${Date.now()}_${safe}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 25 * 1024 * 1024 }
});

router.get("/", getDocuments);
router.get("/:id", getDocumentById);
router.post("/upload", upload.array("files", 10), uploadDocuments);
router.delete("/:id", deleteDocument);
router.post("/sample", loadSampleDossier);
router.post("/clear", clearWorkspace);

module.exports = router;
