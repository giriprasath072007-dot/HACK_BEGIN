require("dotenv").config();
const express = require("express");
const cors = require("cors");
const path = require("path");
const { connectDB, getMongoStatus } = require("./config/db");

const documentRoutes = require("./routes/documentRoutes");
const analysisRoutes = require("./routes/analysisRoutes");
const reportRoutes = require("./routes/reportRoutes");

const app = express();
const PORT = process.env.PORT || 5000;

// Connect to Database
connectDB();

// Middleware
app.use(cors({
  origin: ["http://localhost:5173", "http://127.0.0.1:5173", "http://localhost:3000"],
  credentials: true
}));
app.use(express.json({ limit: "15mb" }));
app.use(express.urlencoded({ extended: true }));

// Serve static uploads if needed
app.use("/uploads", express.static(path.join(__dirname, "uploads")));

// Health & System Status Endpoint
app.get("/api/health", (req, res) => {
  const dbStatus = getMongoStatus();
  res.json({
    status: "ok",
    service: "SourceVerify AI MERN Backend API",
    version: "2.0.0 (MERN)",
    uptime: Math.round(process.uptime()),
    database: dbStatus,
    timestamp: new Date().toISOString()
  });
});

// API Routes
app.use("/api/documents", documentRoutes);
app.use("/api/analysis", analysisRoutes);
app.use("/api/reports", reportRoutes);

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: `Route not found: ${req.originalUrl}` });
});

// Error handling middleware
app.use((err, req, res, next) => {
  console.error("[Backend Error]", err);
  res.status(500).json({ error: err.message || "Internal server error" });
});

const server = app.listen(PORT, () => {
  console.log(`====================================================`);
  console.log(`  SourceVerify AI [MERN Backend] Running`);
  console.log(`  Port:    ${PORT}`);
  console.log(`  API URL: http://localhost:${PORT}/api/health`);
  console.log(`====================================================`);
});

process.on("SIGTERM", () => server.close());
process.on("SIGINT", () => server.close());
