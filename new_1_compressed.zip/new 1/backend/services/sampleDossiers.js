// Sample research dossiers for instant demonstration and testing of SourceVerify AI
module.exports = [
  {
    name: "UN_IPCC_Energy_Transition_Report_2025.txt",
    type: "TXT",
    category: "Government Sources",
    author: "Intergovernmental Panel on Climate Transition (IPCT)",
    publicationDate: "January 2025",
    content: `INTERGOVERNMENTAL PANEL ON CLIMATE TRANSITION (IPCT)
REPORT CODE: IPCT-2025-WG3-GRID
CLASSIFICATION: OFFICIAL INTERGOVERNMENTAL BENCHMARK
DATE: JANUARY 14, 2025

EXECUTIVE SUMMARY: GLOBAL GRID MODERNIZATION & RENEWABLE DEPLOYMENT

1. CAPITAL REQUIREMENTS FOR POWER INFRASTRUCTURE
Global transmission and distribution grid capacity requires $4.2 Trillion cumulative capital expenditure by 2030 to support decarbonized load growth and avert regional brownouts. Approximately 60% of this total must be directed toward HVDC interconnectors and smart substations across North America, Europe, and Asia-Pacific.

2. BATTERY STORAGE COST TRAJECTORY
Utility-scale battery storage costs dropped 68% between 2018 and 2024, driven by scale manufacturing of lithium-iron-phosphate (LFP) chemistry and standardized inverter architectures. Pack-level pricing reached $115/kWh by year-end 2024.

3. RENEWABLE GENERATION TARGETS (2030)
Renewable generation is projected to reach 52% of total worldwide power generation by 2030 under the stated policy Net Zero transition trajectory, with solar PV representing the largest share of incremental capacity additions.

4. FOSSIL FUEL PEAK TIMING
Global coal consumption reached its definitive peak in Q3 2023, after which retirement of subcritical thermal units in OECD nations outpaced additions in developing markets.

5. SYSTEM RELIABILITY STANDARDS
Grid operators must maintain an operating reserve reliability margin above 18% during peak demand periods during high renewable penetration to guarantee grid frequency stability.`
  },
  {
    name: "Global_Energy_Consortium_Q3_Review.txt",
    type: "TXT",
    category: "Commercial Sources",
    author: "Global Energy & Infrastructure Markets Consortium",
    publicationDate: "November 2024",
    content: `GLOBAL ENERGY & INFRASTRUCTURE MARKETS CONSORTIUM (GEIMC)
ANNUAL SECTOR INTELLIGENCE REPORT
PUBLICATION ID: GEIMC-COMM-2024-Q3
DATE: NOVEMBER 18, 2024

COMMERCIAL FORECAST & SUPPLY CHAIN CONSTRAINTS IN ENERGY SYSTEMS

1. CAPITAL REQUIREMENTS FOR POWER INFRASTRUCTURE
Due to severe copper procurement inflation, transformer lead times of 120-140 weeks, and high specialized labor costs, global grid modernization requires $6.8 Trillion in cumulative capital expenditure by 2030. Prior public models substantially underestimate permitting delay costs and supply bottleneck premiums.

2. BATTERY STORAGE COST TRAJECTORY
While cell-level prices have declined, comprehensive utility-scale battery storage capital costs have dropped only 44% since 2018 when balance-of-system (BOS) engineering, EPC overhead, and interconnection fees are accounted for. Turnkey system costs remained at $192/kWh in late 2024.

3. RENEWABLE GENERATION TARGETS (2030)
Renewable generation will reach only 39% of total worldwide generation by 2030, constrained by severe interconnection queue backlogs (over 2,600 GW pending worldwide) and curtailment risks.

4. FOSSIL FUEL PEAK TIMING
Global coal consumption will not peak until 2027-2028, as rapid industrialization in Southeast Asia and South Asia necessitates continued baseload thermal generation amidst intermittent power curtailments.

5. SYSTEM RELIABILITY STANDARDS
To mitigate winter blackout risks with intermittent wind/solar generation, regulators must enforce a minimum operating reserve reliability margin of 25%, significantly above older 15-18% guidelines.`
  },
  {
    name: "MIT_Stanford_Renewables_Empirical_Study_2025.txt",
    type: "TXT",
    category: "Academic / Research",
    author: "Joint Energy Transition Laboratory (MIT & Stanford University)",
    publicationDate: "February 2025",
    content: `JOURNAL OF APPLIED ENERGY SYSTEMS & POLICY
DOI: 10.1016/j.jappeng.2025.109822
PEER-REVIEWED EMPIRICAL RESEARCH ARTICLE
AUTHORS: Dr. Elena Rostova (MIT), Prof. Marcus Vance (Stanford University)
DATE: FEBRUARY 02, 2025

CROSS-SECTIONAL EMPIRICAL ANALYSIS OF GRID CAPITAL REQUIREMENTS AND RENEWABLE INTEGRATION (2020-2035)

ABSTRACT:
We synthesized empirical grid deployment and cost data across 42 national electrical jurisdictions to reconcile divergent institutional projections for 2030 energy transition milestones.

1. CAPITAL REQUIREMENTS FOR POWER INFRASTRUCTURE
Our multi-regional econometric model estimates required global grid modernization expenditure at $4.6 Trillion (95% CI: $4.25T - $4.95T) by 2030. Earlier industry estimates ($6.8T) assumed static equipment inflation that has begun moderating as Chinese and European transformer production expands.

2. BATTERY STORAGE COST TRAJECTORY
Divergence in published battery cost trends is primarily methodological: raw lithium-iron-phosphate (LFP) pack costs fell 65.4% (matching intergovernmental data), whereas turnkey installed systems including balance-of-system (BOS) and grid tie-ins fell 51.2% over the same 2018-2024 timeframe.

3. RENEWABLE GENERATION TARGETS (2030)
Empirical deployment velocity across surveyed nations models renewable generation reaching 47.3% of global electricity production by 2030, assuming recent FERC and European Commission interconnection streamlining reforms achieve 50% effectiveness.

4. FOSSIL FUEL PEAK TIMING
Empirical generation data demonstrates global coal plateauing between Q4 2023 and Q2 2025. Peak timing varies regionally, but aggregate global carbon intensity of electricity generation began an irreversible annual decline in 2024.

5. SYSTEM RELIABILITY STANDARDS
Empirical dynamic grid simulations reveal that with 4-hour battery peaking plants and automated dynamic line rating (DLR), an operating reserve margin of 19.5% provides equal or superior loss-of-load-probability (LOLP) compared to historical 25% margins.`
  }
];
