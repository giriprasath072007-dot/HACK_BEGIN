const mongoose = require("mongoose");

const ClaimSchema = new mongoose.Schema({
  id: { type: String, required: true },
  documentId: { type: String, required: true },
  documentName: { type: String, required: true },
  topicId: { type: String },
  topic: { type: String },
  snippet: { type: String },
  metric: { type: String },
  metricValue: { type: mongoose.Schema.Types.Mixed },
  metricUnit: { type: String },
  confidence: { type: Number, default: 80 }
});

const DocumentSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  name: { type: String, required: true },
  type: { type: String, default: "TXT" },
  size: { type: String, default: "0 KB" },
  sizeBytes: { type: Number, default: 0 },
  added: { type: String },
  category: { type: String, default: "User-Provided Documents" },
  identified: { type: Boolean, default: false },
  credibilityScore: { type: Number, default: 60 },
  authorityLevel: { type: String, default: "Indicative" },
  author: { type: String, default: "Unknown Institution" },
  publicationDate: { type: String, default: "2025" },
  content: { type: String, default: "" },
  claims: [ClaimSchema]
}, {
  timestamps: true
});

module.exports = mongoose.models.Document || mongoose.model("Document", DocumentSchema);
