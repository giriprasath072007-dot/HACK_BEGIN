const mongoose = require("mongoose");

const ConflictSchema = new mongoose.Schema({
  id: { type: String, required: true, unique: true },
  topic: { type: String, required: true },
  topicId: { type: String, required: true },
  severity: { type: String, default: "Medium Divergence" },
  conflictType: { type: String, default: "Quantitative Discrepancy" },
  documentA: {
    id: { type: String },
    name: { type: String },
    statement: { type: String },
    metric: { type: String }
  },
  documentB: {
    id: { type: String },
    name: { type: String },
    statement: { type: String },
    metric: { type: String }
  },
  synthesis: { type: String },
  recommendation: { type: String }
}, {
  timestamps: true
});

module.exports = mongoose.models.Conflict || mongoose.model("Conflict", ConflictSchema);
