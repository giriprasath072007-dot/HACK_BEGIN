const engine = require("../services/intelligenceEngine");
const { getMemoryState } = require("./documentController");

exports.getExecutiveReport = async (req, res) => {
  try {
    const { documents, conflicts } = getMemoryState();
    const format = (req.query.format || "json").toLowerCase();
    const reportData = engine.generateExecutiveReport(documents, conflicts);

    if (format === "markdown" || format === "txt") {
      let md = `# SOURCEVERIFY AI — MERN INTELLIGENCE & CONFLICT AUDIT REPORT\n`;
      md += `*Generated: ${new Date(reportData.generatedAt).toLocaleString()}*\n\n`;
      md += `## 1. EXECUTIVE SUMMARY\n`;
      md += `- Ingested Documents: ${reportData.metadata.totalDocuments}\n`;
      md += `- High Authority Sources: ${reportData.metadata.verifiedSources}\n`;
      md += `- Unverified / Review: ${reportData.metadata.needsReview}\n`;
      md += `- Cross-Document Contradictions: ${reportData.metadata.totalConflicts} (${reportData.metadata.highSeverityConflicts} High Severity)\n`;
      md += `- Average Source Credibility: ${reportData.metadata.averageCredibility}%\n\n`;

      md += `## 2. DOCUMENT INVENTORY\n`;
      reportData.documentsSummary.forEach((d, idx) => {
        md += `${idx + 1}. **${d.name}**\n`;
        md += `   - Category: ${d.category} | Authority: ${d.authorityLevel} (${d.credibilityScore}%)\n`;
        md += `   - Size: ${d.size} | Extracted Claims: ${d.claimCount}\n\n`;
      });

      md += `## 3. CONFLICT COMPARISONS & EVIDENCE\n`;
      if (reportData.conflicts.length === 0) {
        md += `No contradictions found among analyzed sources.\n\n`;
      } else {
        reportData.conflicts.forEach((c, idx) => {
          md += `### ${idx + 1}. ${c.topic} [${c.severity}]\n`;
          md += `- **Type:** ${c.conflictType}\n`;
          md += `- **Source A (${c.documentA.name}):** "${c.documentA.statement}" (Metric: ${c.documentA.metric || 'N/A'})\n`;
          md += `- **Source B (${c.documentB.name}):** "${c.documentB.statement}" (Metric: ${c.documentB.metric || 'N/A'})\n`;
          md += `- **AI Synthesis:** ${c.synthesis}\n`;
          md += `- **Recommendation:** ${c.recommendation}\n\n`;
        });
      }

      md += `## 4. AUDIT DISCLAIMER\n`;
      md += `${reportData.disclaimer}\n`;

      res.setHeader("Content-Disposition", `attachment; filename=SourceVerify-Report-${Date.now()}.${format === "markdown" ? "md" : "txt"}`);
      res.setHeader("Content-Type", "text/plain; charset=utf-8");
      return res.send(md);
    }

    res.json(reportData);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
