const fs = require("fs");
const path = require("path");
const Document = require("../models/Document");
const Conflict = require("../models/Conflict");
const engine = require("../services/intelligenceEngine");
const sampleDossiers = require("../services/sampleDossiers");
const { getMongoStatus } = require("../config/db");

// Local in-memory store for fallback / fast sync
let memoryDocuments = [];
let memoryConflicts = [];

// Helper to format bytes
function formatSize(bytes) {
  if (bytes < 1024 * 1024) return `${Math.max(1, Math.round(bytes / 1024))} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
}

// Helper to extract text from files
function extractText(filePath, originalName) {
  const ext = path.extname(originalName).toLowerCase();
  try {
    if (ext === ".pdf") {
      const buf = fs.readFileSync(filePath);
      const str = buf.toString("latin1");
      const textMatches = str.match(/\(([^()]{3,})\)[\s]*T[jJ]/g) || [];
      const extracted = textMatches.map(m => m.replace(/^[\s(]+|[)TjJ\s]+$/g, "")).join(" ");
      return extracted.length > 50 ? extracted : `PDF document: ${originalName} (Processed).`;
    }
    if (ext === ".docx") {
      const buf = fs.readFileSync(filePath);
      const str = buf.toString("utf8");
      const clean = str.replace(/<[^>]+>/g, " ").replace(/\s+/g, " ");
      return clean.length > 50 ? clean : `DOCX document: ${originalName} (Processed).`;
    }
    return fs.readFileSync(filePath, "utf-8");
  } catch (err) {
    console.error("Text extraction error:", err);
    return `Error reading file: ${err.message}`;
  }
}

// Initialize seed data
const seedSampleDossiers = async () => {
  const docs = sampleDossiers.map((sample, idx) => {
    const classification = engine.classifyDocument(sample.name, sample.content);
    const docObj = {
      id: `doc-sample-${idx + 1}`,
      name: sample.name,
      type: sample.type,
      size: `${Math.round(sample.content.length / 1024 * 10) / 10} KB`,
      sizeBytes: sample.content.length,
      added: new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(new Date()),
      category: sample.category || classification.category,
      identified: classification.identified,
      credibilityScore: classification.credibilityScore,
      authorityLevel: classification.authorityLevel,
      author: sample.author || "Research Institution",
      publicationDate: sample.publicationDate || "2025",
      content: sample.content,
      claims: []
    };
    docObj.claims = engine.extractClaims(docObj);
    return docObj;
  });

  memoryDocuments = docs;
  memoryConflicts = engine.detectConflicts(memoryDocuments);

  // If MongoDB is connected, also upsert to database
  if (getMongoStatus().connected) {
    try {
      await Document.deleteMany({});
      await Conflict.deleteMany({});
      await Document.insertMany(docs);
      await Conflict.insertMany(memoryConflicts);
    } catch (e) {
      console.warn("MongoDB initial seed sync warning:", e.message);
    }
  }
};

// Seed on module load
seedSampleDossiers();

// Controller handlers
exports.getDocuments = async (req, res) => {
  try {
    let docs = [];
    if (getMongoStatus().connected) {
      docs = await Document.find({}).sort({ createdAt: -1 });
    }
    if (!docs || docs.length === 0) {
      docs = memoryDocuments;
    }

    const sanitized = docs.map(doc => ({
      id: doc.id,
      name: doc.name,
      type: doc.type,
      size: doc.size,
      sizeBytes: doc.sizeBytes,
      added: doc.added,
      category: doc.category,
      identified: doc.identified,
      credibilityScore: doc.credibilityScore,
      authorityLevel: doc.authorityLevel,
      author: doc.author,
      publicationDate: doc.publicationDate,
      claimsCount: (doc.claims || []).length,
      contentPreview: (doc.content || "").slice(0, 300)
    }));
    res.json(sanitized);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getDocumentById = async (req, res) => {
  try {
    let doc = null;
    if (getMongoStatus().connected) {
      doc = await Document.findOne({ id: req.params.id });
    }
    if (!doc) {
      doc = memoryDocuments.find(d => d.id === req.params.id);
    }
    if (!doc) return res.status(404).json({ error: "Document not found" });
    res.json(doc);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.uploadDocuments = async (req, res) => {
  try {
    if (!req.files || req.files.length === 0) {
      return res.status(400).json({ error: "No files uploaded" });
    }

    const addedDocs = [];
    for (const file of req.files) {
      const ext = path.extname(file.originalname).replace(".", "").toUpperCase();
      const content = extractText(file.path, file.originalname);
      const classification = engine.classifyDocument(file.originalname, content);

      const newDoc = {
        id: `doc-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
        name: file.originalname,
        type: ext || "TXT",
        size: formatSize(file.size),
        sizeBytes: file.size,
        added: new Intl.DateTimeFormat(undefined, { month: "short", day: "numeric", year: "numeric" }).format(new Date()),
        category: classification.category,
        identified: classification.identified,
        credibilityScore: classification.credibilityScore,
        authorityLevel: classification.authorityLevel,
        author: "Uploaded Source",
        publicationDate: new Date().getFullYear().toString(),
        content: content,
        claims: []
      };

      newDoc.claims = engine.extractClaims(newDoc);
      memoryDocuments.push(newDoc);
      addedDocs.push(newDoc);

      if (getMongoStatus().connected) {
        try {
          await Document.create(newDoc);
        } catch (e) {
          console.warn("MongoDB insert error:", e.message);
        }
      }
    }

    memoryConflicts = engine.detectConflicts(memoryDocuments);
    if (getMongoStatus().connected) {
      try {
        await Conflict.deleteMany({});
        await Conflict.insertMany(memoryConflicts);
      } catch (e) {}
    }

    res.json({
      message: `Successfully ingested ${addedDocs.length} document(s).`,
      added: addedDocs.map(d => ({ id: d.id, name: d.name, category: d.category })),
      totalDocuments: memoryDocuments.length,
      totalConflicts: memoryConflicts.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.deleteDocument = async (req, res) => {
  try {
    const { id } = req.params;
    const index = memoryDocuments.findIndex(d => d.id === id);
    let removedName = "Document";

    if (index !== -1) {
      removedName = memoryDocuments[index].name;
      memoryDocuments.splice(index, 1);
    }

    if (getMongoStatus().connected) {
      await Document.deleteOne({ id });
    }

    memoryConflicts = engine.detectConflicts(memoryDocuments);
    if (getMongoStatus().connected) {
      await Conflict.deleteMany({});
      await Conflict.insertMany(memoryConflicts);
    }

    res.json({
      message: `Document "${removedName}" deleted.`,
      remainingCount: memoryDocuments.length,
      conflictsCount: memoryConflicts.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.loadSampleDossier = async (req, res) => {
  try {
    await seedSampleDossiers();
    res.json({
      message: "Sample research dossier loaded successfully.",
      totalDocuments: memoryDocuments.length,
      totalConflicts: memoryConflicts.length
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.clearWorkspace = async (req, res) => {
  try {
    memoryDocuments = [];
    memoryConflicts = [];
    if (getMongoStatus().connected) {
      await Document.deleteMany({});
      await Conflict.deleteMany({});
    }
    res.json({ message: "Workspace cleared successfully.", totalDocuments: 0, totalConflicts: 0 });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getMemoryState = () => ({
  documents: memoryDocuments,
  conflicts: memoryConflicts,
  setConflicts: (newConflicts) => { memoryConflicts = newConflicts; }
});
