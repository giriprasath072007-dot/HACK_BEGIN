const engine = require("../services/intelligenceEngine");
const Conflict = require("../models/Conflict");
const Document = require("../models/Document");
const { getMongoStatus } = require("../config/db");
const { getMemoryState } = require("./documentController");

exports.runAnalysis = async (req, res) => {
  try {
    const state = getMemoryState();
    const docs = state.documents;

    docs.forEach(doc => {
      const classification = engine.classifyDocument(doc.name, doc.content);
      doc.category = classification.category;
      doc.identified = classification.identified;
      doc.credibilityScore = classification.credibilityScore;
      doc.authorityLevel = classification.authorityLevel;
      doc.claims = engine.extractClaims(doc);
    });

    const conflicts = engine.detectConflicts(docs);
    state.setConflicts(conflicts);

    if (getMongoStatus().connected) {
      try {
        await Conflict.deleteMany({});
        await Conflict.insertMany(conflicts);
        for (const d of docs) {
          await Document.updateOne({ id: d.id }, { $set: d }, { upsert: true });
        }
      } catch (e) {}
    }

    const report = engine.generateExecutiveReport(docs, conflicts);

    res.json({
      message: "Cross-document analysis completed successfully.",
      documentsCount: docs.length,
      conflictsCount: conflicts.length,
      conflicts: conflicts,
      summary: report
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};

exports.getConflicts = async (req, res) => {
  try {
    const state = getMemoryState();
    let conflicts = state.conflicts;

    if (getMongoStatus().connected) {
      const dbConflicts = await Conflict.find({});
      if (dbConflicts && dbConflicts.length > 0) {
        conflicts = dbConflicts;
      }
    }

    res.json({
      total: conflicts.length,
      conflicts: conflicts,
      timestamp: new Date().toISOString()
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
};
