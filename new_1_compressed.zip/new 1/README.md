# SourceVerify AI — Full-Stack MERN Architecture

> **Intelligent Source Verification, Document Intelligence, & Cross-Document Conflict Detection Workspace**

Built as a decoupled **MERN Stack** (MongoDB, Express, React, Node.js) with independent `backend` and `frontend` layers.

---

## 🏗️ Architecture & Technology Stack

| Layer | Technology | Port | Responsibilities |
|---|---|---|---|
| **Frontend** | React 18, Vite 5, Vanilla CSS | `5173` | Modern SPA with dark/light themes, reactive conflict explorer, drag-and-drop upload, inspector modals, and export studio. |
| **Backend** | Node.js, Express 4 | `5000` | REST API, multi-file ingestion (Multer), text parsing, natural language claim extraction, and cross-document contradiction matrix. |
| **Database** | MongoDB / Mongoose | `27017` | Document schemas with embedded claims, conflict comparison records, and authority audit trails (with instant hybrid memory fallback if local MongoDB is not yet running). |

---

## 📁 Project Structure

```
new 1/
├── backend/                        # Node.js + Express + MongoDB Server
│   ├── .env                        # Environment variables (PORT, MONGO_URI, CLIENT_URL)
│   ├── package.json                # Express, Mongoose, Multer, Cors, Dotenv
│   ├── server.js                   # Backend entry point
│   ├── config/
│   │   └── db.js                   # Mongoose connection with hybrid fallback
│   ├── models/
│   │   ├── Document.js             # Mongoose Document & Claim Schema
│   │   └── Conflict.js             # Mongoose Cross-Document Conflict Schema
│   ├── controllers/
│   │   ├── documentController.js   # Ingestion, text parsing, deletion, sample dossiers
│   │   ├── analysisController.js   # Claim extraction & contradiction comparison
│   │   └── reportController.js     # Executive audit report serialization
│   ├── routes/
│   │   ├── documentRoutes.js       # /api/documents/*
│   │   ├── analysisRoutes.js       # /api/analysis/*
│   │   └── reportRoutes.js         # /api/reports/*
│   ├── services/
│   │   ├── intelligenceEngine.js   # Linguistic and quantitative conflict detection engine
│   │   └── sampleDossiers.js       # Preloaded institutional test dossiers
│   └── uploads/                    # Local storage directory for uploaded files
│
├── frontend/                       # React 18 + Vite SPA
│   ├── package.json                # React, ReactDOM, Vite, @vitejs/plugin-react
│   ├── vite.config.js              # Vite server & API proxy
│   ├── index.html                  # HTML entry point with modern typography
│   └── src/
│       ├── main.jsx                # React DOM mounting
│       ├── App.jsx                 # Central application state manager
│       ├── index.css               # Design system & dark/light theme
│       ├── components/
│       │   ├── Sidebar.jsx         # Navigation sidebar & active view tracker
│       │   ├── Topbar.jsx          # Live database indicator & theme switcher
│       │   └── DocumentModal.jsx   # Raw text & extracted claims inspector
│       ├── views/
│       │   ├── OverviewView.jsx    # Metric dashboard & recent documents
│       │   ├── DocumentsView.jsx   # Searchable & filterable library
│       │   ├── SourcesView.jsx     # Institutional category landscape
│       │   ├── AnalysisView.jsx    # Side-by-side contradiction matrix
│       │   ├── ReportsView.jsx     # Multi-format report export studio
│       │   └── AboutView.jsx       # Architecture & privacy breakdown
│       └── services/
│           └── api.js              # Fetch client connected to backend
│
├── start-all.bat                   # 🚀 1-Click launcher (starts backend + frontend)
├── start-backend.bat               # Starts only the Express backend
├── start-frontend.bat              # Starts only the React frontend
└── README.md                       # Comprehensive guide
```

---

## 🚀 Quick Start Guide

### Option 1: 1-Click Launch (Recommended for Windows)
Double-click:
```
start-all.bat
```
*This launches both the backend and frontend dev servers in separate windows and automatically opens `http://localhost:5173` in your browser.*

---

### Option 2: Running via Terminal

#### 1. Start the Backend:
```bash
cd backend
npm start
```
*The backend starts at `http://localhost:5000`.*

#### 2. Start the Frontend (in a separate terminal):
```bash
cd frontend
npm run dev
```
*The React frontend starts at `http://localhost:5173`.*

---

## 📡 REST API Documentation

### Documents API (`/api/documents`)
- `GET /api/documents`: List all ingested documents with metadata and claim counts.
- `GET /api/documents/:id`: Fetch single document with full content and claims.
- `POST /api/documents/upload`: Multi-file upload (`multipart/form-data`) supporting `.txt`, `.md`, `.csv`, `.pdf`, `.docx`, `.json`.
- `DELETE /api/documents/:id`: Delete a document and recalculate cross-document contradictions.
- `POST /api/documents/sample`: Ingest pre-configured multi-institution research dossiers.
- `POST /api/documents/clear`: Clear all documents.

### Analysis API (`/api/analysis`)
- `POST /api/analysis/run`: Run deep claim extraction, authority scoring, and cross-document contradiction detection.
- `GET /api/analysis/conflicts`: Return array of detected discrepancies with side-by-side evidence quotes.

### Reports API (`/api/reports`)
- `GET /api/reports?format=json`: Executive summary in JSON.
- `GET /api/reports?format=markdown`: Formatted report in Markdown (`.md`).
- `GET /api/reports?format=txt`: Plain text audit report (`.txt`).

---

## 🧠 Cross-Document Intelligence Engine

1. **Institutional Classification & Authority Scoring:**
   - Evaluates sources into 8 institutional tiers (Government, Academic/Peer-Reviewed, Official NGO, Commercial/Industry, News Media, etc.).
   - Computes a 0–100% credibility score based on DOI presence, empirical methodology, confidence intervals, and publication pedigree.

2. **Claim & Metric Extraction:**
   - Scans text for quantitative statements, timelines, and statistical assertions.
   - Categorizes findings by topic (Grid Capital Requirements, Battery Storage Trajectory, Renewable Targets 2030, Peak Coal Timeline, Reserve Margins).

3. **Pairwise Contradiction Detection:**
   - Automatically surfaces conflicting claims across disparate documents.
   - Renders side-by-side evidence cards comparing **Source A** vs **Source B**.
   - Computes severity: `High Contradiction`, `Divergent Projection`, or `Methodological Difference`.
   - Generates an **Intelligence Synthesis** explaining the root cause of the variance.

---

## 🗄️ MongoDB Configuration & Fallback

In `backend/.env`:
```env
PORT=5000
MONGO_URI=mongodb://127.0.0.1:27017/sourceverify
CLIENT_URL=http://localhost:5173
```
- If MongoDB is running on your machine, Mongoose connects and persists all documents and conflict matrices.
- If MongoDB is not yet running, the system automatically falls back to **Hybrid In-Memory Storage**, allowing you to test and run the entire application immediately without any setup hurdles.
